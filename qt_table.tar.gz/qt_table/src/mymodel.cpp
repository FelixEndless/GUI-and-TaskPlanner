/****************************************************************************
 **
 ** Copyright (C) 2013 Digia Plc and/or its subsidiary(-ies).
 ** Contact: http://www.qt-project.org/legal
 **
 ** This file is part of the examples of the Qt Toolkit.
 **
 ** $QT_BEGIN_LICENSE:BSD$
 ** You may use this file under the terms of the BSD license as follows:
 **
 ** "Redistribution and use in source and binary forms, with or without
 ** modification, are permitted provided that the following conditions are
 ** met:
 **   * Redistributions of source code must retain the above copyright
 **     notice, this list of conditions and the following disclaimer.
 **   * Redistributions in binary form must reproduce the above copyright
 **     notice, this list of conditions and the following disclaimer in
 **     the documentation and/or other materials provided with the
 **     distribution.
 **   * Neither the name of Digia Plc and its Subsidiary(-ies) nor the names
 **     of its contributors may be used to endorse or promote products derived
 **     from this software without specific prior written permission.
 **
 **
 ** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 ** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 ** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 ** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 ** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 ** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 ** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 ** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 ** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 ** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 ** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
 **
 ** $QT_END_LICENSE$
 **
 ****************************************************************************/

#include <QFont>
#include <QBrush>
#include <QColor>
#include "mymodel.h"
#include <QDebug>
#include <string>
#include <sstream>
#include "callback.h"
#include <QApplication>


MyModel::MyModel(QObject *parent, int row)
:QAbstractTableModel(parent),
 _row(row)

{
	ros::NodeHandle prvNh("~");
	prvNh.param<bool>("startOption",_startGUI, false);
	if(_startGUI)
	{
		_time = time(NULL);
		_localTime = *localtime(&_time);
		fileName = "records_from_" + std::to_string(_localTime.tm_mday) + "_" +std::to_string( _localTime.tm_mon+1) +"_" +std::to_string(_localTime.tm_year+1900) + "_" +"at" +"_"+std::to_string( _localTime.tm_hour)+"_"+std::to_string(_localTime.tm_min) + "_"+std::to_string( _localTime.tm_sec)+".txt";
		path = "/home/kuiekemjo41682/catkin_ws/src/qt_table/record/" + std::string(fileName);
		_subTaskVectorClient = _nh.serviceClient<youbot_msgs::pop_subTaskVector>("subTask");
		while (!_subTaskVectorClient.call(srv)){
			ROS_WARN_THROTTLE(4, "No subtask vector");
			sleep(1);
		}
		_subTasks = srv.response.subTasks;
		_row = _subTasks.subtasks.size();
		_rowCount = 0;
		for(unsigned int i = 0; i<_subTasks.subtasks.size();i++)
		{
			std::vector<std::string> singleTask;
			singleTask.push_back(_subTasks.subtasks.at(i).subTasktType.data());
			singleTask.push_back(_subTasks.subtasks.at(i).serviceArea.data());
			if(_subTasks.subtasks.at(i).subTasktType == "W")
			{
				continue;
			}
			else if(_subTasks.subtasks.at(i).subTasktType == "M"){
				singleTask.push_back("");}
			else
			{
				singleTask.push_back(_subTasks.subtasks.at(i).objectType.data());

			}
			singleTask.push_back("");
			singleTask.push_back("");
			singleTask.push_back("");
			_taskResults.push_back(singleTask);
		}
		_initialized = true;
		//MyModel::_once = true;
		_timerMain.start(10);
		connect(&_timerMain,SIGNAL(timeout(void)),this,SLOT(run(void)));
		_actualTask = 0;
		_updateUI = 0;
		_refresh = new QTimer(this);
		_refresh->setInterval(1000);
		connect(_refresh,SIGNAL(timeout()),this, SLOT(refreshTable()));
		_refresh->start();

	}
	else
	{
		QApplication::quit();
	}


}
void MyModel::refreshTable()
{
	//_updateUI++;
	 //we identify the top left cell
	    QModelIndex index1 = createIndex(_actualTask-1, 3);
	    QModelIndex index2 = createIndex(_actualTask-1, 5);
	    //emit a signal to make the view reread identified data
	    emit dataChanged(index1,index2);

}
bool MyModel::setUpdate()
{

	if(_updateUI >=1)
	{
		return true;
	}
	else
	{
		return false;
	}
}
void MyModel::run()
{
	ros::Rate r(1);
	if (_initialized){

		if(_rowCount == 0){
			_serviceResults =_nh.advertiseService("results",&MyModel::fillResultsCallBack,this);
			_rowCount++;
		}
		ROS_INFO_ONCE("Initialization finished");
		ros::spinOnce();
	}

	ros::spinOnce();
	r.sleep();
}

int MyModel::rowCount(const QModelIndex & /*parent */) const
{
	return _row;
}

int MyModel::columnCount(const QModelIndex & /*parent */) const
{
	return 6;
}

//! [Quoting ModelView Tutorial]
// mymodel.cpp
QVariant MyModel::data(const QModelIndex &index, int role) const
{

	//ROS_INFO("Subtasks received correctly. Creating GUI...");
	unsigned int row = index.row();
	unsigned int col = index.column();
	// generate a log message when this method gets called
	//qDebug() << QString("row %1, col%2, role %3")
	//       .arg(row).arg(col).arg(role);

	switch(role){
	/*case Qt::DisplayRole:
        if (col == 0 && row != 0) //change font only for cell(0,0)
        {
        return QString("%1")
                .arg(row)
	}
	break;
	 */
	case Qt::BackgroundRole:

		for(unsigned int i = 0; i<_taskResults.size();i++)
		{
			if (col > 2)
			{
				QBrush greenBackground(Qt::green);
				QBrush redBackground(Qt::red);
				if(row == i && col == 3 && strcmp(_taskResults.at(i).at(3).data(), "Success")==0)
					return greenBackground;
				if(row == i && col == 4 && strcmp(_taskResults.at(i).at(4).data(), "Success")==0)
					return greenBackground;
				if(row == i && col == 5 && strcmp(_taskResults.at(i).at(5).data(), "Success")==0)
					return greenBackground;
				if(row == i && col == 3 && strcmp(_taskResults.at(i).at(3).data(), "")!=0)
					return redBackground;
				if(row == i && col == 4 && strcmp(_taskResults.at(i).at(4).data(), "")!=0)
					return redBackground;
				if(row == i && col == 5 && strcmp(_taskResults.at(i).at(5).data(), "")!=0)
					return redBackground;

			}
		}
        break;
	/*case Qt::TextAlignmentRole:

        if (row == 1 && col == 1) //change text alignment only for cell(1,1)
        {
            return Qt::AlignRight + Qt::AlignVCenter;
        }
        break;*/
	case Qt::DisplayRole:

		for(unsigned int i = 0; i<_taskResults.size();i++)
		{
			if(row == i && col == 0)
				return QString(_taskResults.at(i).at(0).data());
			if(_taskResults.at(i).at(0) == "M")
			{
				if (row == i && col == 1)
					return QString(_taskResults.at(i).at(1).data());
				if (row == i && col == 2)
					return QString(" ");
			}
			if(_subTasks.subtasks.at(i).subTasktType == "W")
			{
				continue;
			}
			if (row == i && col == 1)
				return QString(_taskResults.at(i).at(1).data());
			if (row == i && col == 2)
				return QString(_taskResults.at(i).at(2).data());



			if (row == i && col == 3)
			{
				return QString(_taskResults.at(i).at(3).data());

			}
			if (row == i && col == 4)
			{
				return QString(_taskResults.at(i).at(4).data());

			}
			if (row == i && col == 5)
			{
				return QString(_taskResults.at(i).at(5).data());

			}
		}
	}
	return QVariant();
}

QVariant MyModel::headerData(int section, Qt::Orientation orientation, int role) const
{
	if (role == Qt::DisplayRole)
	{
		if (orientation == Qt::Horizontal) {
			switch (section)
			{
			case 0:
				return QString("taskType");
			case 1:
				return QString("location");
			case 2:
				return QString("objectType");
			case 3:
				return QString("navigationResult");
			case 4:
				return QString("visionResult");
			case 5:
				return QString("manipulationResult");
			}
		}
		if (orientation == Qt::Vertical) {
			/* switch (section)
            {
            case 0:
                return QString("1");
            case 1:
                return QString("2");
            case 2:
                return QString("3");
	    case 3:
                return QString("4");
            case 4:
                return QString("5");
            case 5:
                return QString("6");
            }*/
			for (unsigned int i= section; i< _row;i++)
			{
				int wert = i+1;
				//std::string s = std::to_string(wert);
				return QString::number(wert);
			}
		}
	}
	if (role == Qt::FontRole)
	{
		QFont boldFont;
		boldFont.setBold(true);
		return boldFont;
	}
	return QVariant();
}
bool MyModel::fillResultsCallBack(youbot_msgs::taskResults::Request &req,youbot_msgs::taskResults::Response &res)
{
	unsigned int resultType = req.resultType;
	file.open(path,std::ofstream::out | std::ofstream::app);
	//std::stringstream ss;
	//ss << req.resultType;
	std::string line;
	//line = "result type "+ std::to_string(req.resultType) + " and subtaskType " + req.currentSubtask.subTasktType + " returned with " + req.result + "\n";

	ROS_INFO_STREAM("FillResultsCallBack. taskType: " << req.currentSubtask.subTasktType << " location: " << req.currentSubtask.serviceArea << " objectType: " << req.currentSubtask.objectType);
	ROS_INFO_STREAM("FillResultsCallBack. resultType: " << resultType << " result: " << req.result);
	//int count = 0;
	for (unsigned int i = _actualTask; i <_taskResults.size();i++)
	{
		//file << _taskResults.at(i).at(0);
		//file << _taskResults.at(i).at(1);
		ROS_INFO_STREAM("_taskResults. taskType: " <<  _taskResults.at(i).at(0) << " serviceArea: " <<  _taskResults.at(i).at(1));
			if (req.currentSubtask.subTasktType != _taskResults.at(i).at(0)
									|| req.currentSubtask.serviceArea != _taskResults.at(i).at(1)
									|| (_taskResults.at(i).at(2).size() && req.currentSubtask.objectType != _taskResults.at(i).at(2))
								){
								//ROS_INFO_STREAM("if condition matched, continuing the loop");
								continue;
								}
		ROS_INFO_STREAM("checking");

		line = "TaskType: " +std::string (req.currentSubtask.subTasktType) + " location: " + std::string(req.currentSubtask.serviceArea) + " objectType: " +std::string( req.currentSubtask.objectType) + "\n";
		file << line;
		if (req.resultType == req.navigationResult)
		{
			_taskResults.at(i).at(3) = req.result;
			_actualColumn = 4;
			line = "Navigation result: " + req.result + "\n";
			file <<line;
		}
		else if (req.resultType == req.visionResult)
		{
			_taskResults.at(i).at(4) = req.result;
			line = "Vision result: " + req.result + "\n";
			ROS_INFO_STREAM("Vision result: " << req.result);
			_actualColumn = 5;
			file <<line;
		}
		else if (req.resultType == req.manipulationResult)
		{
			line = "Manipulation result: " + req.result + "\n";
			_taskResults.at(i).at(5) = req.result;
			ROS_INFO_STREAM("Manipulation result: " << req.result);
			_actualColumn = 6;
			file << line;
		}
		else {
			line = "Incorrect resultType received \n";
			file <<line ;
			ROS_ERROR_STREAM("Incorrect resultType received: " << req.result);
			return false;
		}
		/*if(_taskResults.at(i).at(1) == "PRE_FINISH" && _taskResults.at(i).at(0) == "E")
		{
			_actualTask = 0;
		}
		else
		{
			_actualTask = i;
		}*/
		_actualTask = i;
		break;
	}
	file.close();
	return true;
}
bool MyModel::startOption()
{
	return _startGUI;
}
//! [Quoting ModelView Tutorial]
