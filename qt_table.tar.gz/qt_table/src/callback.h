/*
 * callback.h
 *
 *  Created on: 19.02.2018
 *      Author: kuiekemjo41682
 */

#ifndef SRC_CALLBACK_H_
#define SRC_CALLBACK_H_
#include "youbot_msgs/pop_subTaskVector.h"
#include "youbot_msgs/SubTask.h"
#include "youbot_msgs/SubTaskVector.h"
#include "youbot_msgs/taskResults.h"
#include "ros/ros.h"

namespace fc {

class callback {
public:
	callback();
	virtual ~callback();
	bool fillResultsCallBack(youbot_msgs::taskResults::Request &req,
	    		youbot_msgs::taskResults::Response &res);
	std::vector<std::vector<std::string>> getResults();
private:
	std::vector<std::vector<std::string>> _taskResults;
};

} /* namespace fc */

#endif /* SRC_CALLBACK_H_ */
