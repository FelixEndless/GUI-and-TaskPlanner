#ifndef WINDOW_H
#define WINDOW_H
#ifndef Q_MOC_RUN
#include <QMainWindow>
#include <QTableView>
#include <QItemDelegate>
#include <QStandardItemModel>
#include <QTimer>
#include "ros/ros.h"
#include "youbot_msgs/pop_subTaskVector.h"
#include "youbot_msgs/SubTask.h"
#include "youbot_msgs/SubTaskVector.h"
#include "youbot_msgs/taskResults.h"
#endif
namespace Ui {
class Window;
}


class Window : public QMainWindow
{
	Q_OBJECT

public Q_SLOTS:
	void run(void);
public:
    explicit Window(QWidget *parent = 0);
    ~Window();
    void init();

private:
    Ui::Window *_ui;
    ros::NodeHandle _nh;
    QTimer _timerMain;
    ros::ServiceServer _serviceResults;
    ros::ServiceClient _subTaskVectorClient;
    std::vector<std::vector<std::string>> _taskResults;
    youbot_msgs::SubTaskVector _subTasks;
    QStandardItemModel *model;
};

#endif // WINDOW_H
