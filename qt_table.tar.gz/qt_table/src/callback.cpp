/*
 * callback.cpp
 *
 *  Created on: 19.02.2018
 *      Author: kuiekemjo41682
 */

#include "callback.h"

namespace fc {

callback::callback() {
	// TODO Auto-generated constructor stub

}

callback::~callback() {
	// TODO Auto-generated destructor stub
}
std::vector<std::vector<std::string>> callback::getResults()
{
	return _taskResults;
}
bool callback::fillResultsCallBack(youbot_msgs::taskResults::Request &req,youbot_msgs::taskResults::Response &res)
{
	ROS_INFO("I am in FillResultsCallBack");
	for (int i = 0; i <_taskResults.size();i++)
	{

		if (req.currentSubtask.subTasktType != _taskResults.at(i).at(0)
		        || req.currentSubtask.serviceArea != _taskResults.at(i).at(1)
		        || (_taskResults.at(i).at(2).size() && req.currentSubtask.objectType != _taskResults.at(i).at(2))
		        ){
		      continue;
		    }
		if (req.resultType == req.navigationResult)
		    {
		      _taskResults.at(i).at(3) = req.result;
		    }
		else if (req.resultType == req.visionResult)
		    {
		      _taskResults.at(i).at(4) = req.result;
		    }
		else if (req.resultType == req.manipulationResult)
		    {
		      _taskResults.at(i).at(5) = req.result;
		    }
	    else {
	      ROS_ERROR("Incorrect resultType received");
	      return false;
	    }
		break;
	}
	return true;
}

} /* namespace fc */
