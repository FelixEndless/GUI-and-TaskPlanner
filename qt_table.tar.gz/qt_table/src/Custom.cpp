/*
 * Custom.cpp
 *
 *  Created on: Jan 18, 2018
 *      Author: phil
 */

#include "Custom.h"

Custom::Custom(QWidget* parent):
QWidget(parent),
_customGui(new Ui::CustomWidget),
_penner(0)
{
  _customGui->setupUi(this);

}

Custom::~Custom()
{
  // TODO Auto-generated destructor stub
}

void Custom::incrementPenner(void)
{
  _penner++;
  this->setNPenner(_penner);
  this->update();
}
