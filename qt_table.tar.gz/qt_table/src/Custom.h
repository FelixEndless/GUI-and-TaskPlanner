/*
 * Custom.h
 *
 *  Created on: Jan 18, 2018
 *      Author: phil
 */

#ifndef TESTPRGS_QT_LIST_WIDGET_SRC_CUSTOM_H_
#define TESTPRGS_QT_LIST_WIDGET_SRC_CUSTOM_H_

#include <QWidget>
#include "ui_custom.h"

class Custom: public QWidget
{
  Q_OBJECT
public:
  Custom(QWidget* parent = NULL);
  virtual ~Custom();
  void setNDeppen(int n){_customGui->labelDeppen->setNum(n);}
  void setNPenner(int n){_customGui->labelPenner->setNum(n);}
public slots:
  void incrementPenner(void);
private:
  Ui::CustomWidget* _customGui;
  int _penner;
};

#endif /* TESTPRGS_QT_LIST_WIDGET_SRC_CUSTOM_H_ */
