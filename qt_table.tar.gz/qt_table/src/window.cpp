#include "window.h"
#include "ui_custom.h"

Window::Window(QWidget *parent) :
QMainWindow(parent),_ui(new Ui::Window)
{
	_ui->setupUi(this);
	_subTaskVectorClient = _nh.serviceClient<youbot_msgs::pop_subTaskVector>("subTask");

}
Window::~Window()
{
	delete _ui;
}
void Window::run()
{
    ros::Rate r(1);
    while (ros::ok())
    {
        ros::spinOnce();
        r.sleep();
    }
}

void Window::init()
{
	    youbot_msgs::pop_subTaskVector srv;

	    while(!_subTaskVectorClient.call(srv))
	    {
	        ROS_WARN_THROTTLE(4,"No subtask vector");
	        sleep(1);
	    }
	    _subTasks = srv.response.subTasks;
	    model = new QStandardItemModel(_subTasks.subtasks.size(),6,this);
	    _ui->tableView->setModel(model);
	    for(int i = 0; i<_subTasks.subtasks.size();i++)
	    {
	    	if (i==0)
	    	{
	    		QModelIndex index = model->index(i,0,QModelIndex());
	    		model->setData(index,"taskType");
	    		index = model->index(i,1,QModelIndex());
	    	    model->setData(index,"location");
	    	    index = model->index(i,2,QModelIndex());
	    	    model->setData(index,"objectType");
	    	    index = model->index(i,3,QModelIndex());
	    	    model->setData(index,"navigationResult");
	    	    index = model->index(i,4,QModelIndex());
	    	    model->setData(index,"visionResult");
	    	    index = model->index(i,5,QModelIndex());
	    	    model->setData(index,"manipulationResult");
	    	}
	    }

}
