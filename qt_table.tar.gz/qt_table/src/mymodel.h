/****************************************************************************
**
** Copyright (C) 2013 Digia Plc and/or its subsidiary(-ies).
** Contact: http://www.qt-project.org/legal
**
** This file is part of the examples of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:BSD$
** You may use this file under the terms of the BSD license as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of Digia Plc and its Subsidiary(-ies) nor the names
**     of its contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
** $QT_END_LICENSE$
**
****************************************************************************/

#ifndef MYMODEL_H
#define MYMODEL_H
#ifndef Q_MOC_RUN
//! [Quoting ModelView Tutorial]
// mymodel.h
#include <QAbstractTableModel>
#include "youbot_msgs/pop_subTaskVector.h"
#include "youbot_msgs/SubTask.h"
#include "youbot_msgs/SubTaskVector.h"
#include "youbot_msgs/taskResults.h"
#include "ros/ros.h"
#include <sstream>
#include<string>
#include<QTimer>
#include<iostream>
#include<fstream>
#include<string>
#include<ctime>
#endif
class MyModel : public QAbstractTableModel
{
    Q_OBJECT

public Q_SLOTS:
void run(void);
void refreshTable(void);
public:
    MyModel(QObject *parent, int row);
    virtual ~MyModel() {};
    int rowCount(const QModelIndex &parent = QModelIndex()) const ;
    int columnCount(const QModelIndex &parent = QModelIndex()) const;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const;
    QVariant headerData(int section, Qt::Orientation orientation, int role) const;
    bool fillResultsCallBack(youbot_msgs::taskResults::Request &req,
    	    		youbot_msgs::taskResults::Response &res);
    bool startOption();
    QTimer *_refresh;
    bool setUpdate();

private:
    unsigned int _row, _col,_rowCount;
    bool _initialized= false;
    //static bool _once;
    QTimer _timerMain;
    ros::NodeHandle _nh;
    ros::ServiceServer _serviceResults;
    ros::ServiceClient _subTaskVectorClient;
    std::vector<std::vector<std::string>> _taskResults;
    youbot_msgs::SubTaskVector _subTasks;
    youbot_msgs::pop_subTaskVector srv;
    std::string s;
    bool _startGUI;
    int _updateUI;
    int _actualTask;
    int _actualColumn;
    std::ofstream file;
    std::string path;
    std::string fileName;
    time_t _time;
    struct tm _localTime;
};
//! [Quoting ModelView Tutorial]

#endif // MYMODEL_H
